export { default } from './Regulations';
