export { default } from './Cemetery';
